
from flask import Flask, render_template, request, redirect, url_for, session
import os
import json

app = Flask(__name__)
app.secret_key = 'your_secret_key'

DATA_FILE = 'employees.json'

def load_employees():
    if not os.path.exists(DATA_FILE):
        return {}
    with open(DATA_FILE, 'r') as f:
        return json.load(f)

def save_employees(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=2)

@app.route('/')
def home():
    return redirect('/verify')

@app.route('/verify')
def verify():
    emp_id = request.args.get('id')
    employees = load_employees()
    employee = employees.get(emp_id)
    return render_template('verify.html', employee=employee, emp_id=emp_id)

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if 'user' not in session:
        return redirect('/login')

    employees = load_employees()

    if request.method == 'POST':
        emp_id = request.form['emp_id']
        name = request.form['name']
        dbs = request.form['dbs']
        status = request.form['status']
        photo = request.form['photo']
        employees[emp_id] = {
            "name": name,
            "dbs": dbs,
            "status": status,
            "photo": photo
        }
        save_employees(employees)
        return redirect('/admin')

    return render_template('admin.html', employees=employees)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        if email == 'Joshua@mcsclean.co.uk' and password == 'Mcscleaning1!':
            session['user'] = email
            return redirect('/admin')
        else:
            return "Invalid credentials"
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect('/login')

if __name__ == '__main__':
    app.run(debug=True)
